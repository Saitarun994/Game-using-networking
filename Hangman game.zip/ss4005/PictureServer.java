import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;


public class PictureServer {
	public static int port=1000;
	private DatagramSocket socket;
	private byte buffer[]= new byte[1024];
	InetAddress address;
	
	public PictureServer(DatagramSocket socket)
	{
		this.socket=socket;
	}
	
	public String getData()
	{
		System.out.println("Waiting for data from client . . .");
		try
		{
			byte buffer[]= new byte[1024];
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
			socket.receive(packet);
			address=packet.getAddress();
			port=packet.getPort();
			String line= new String(packet.getData(),0,packet.getLength());
			System.out.println("Message from client "+line);
			return line;
		} 
		catch (IOException e) {e.printStackTrace();}
	return null;
	}
	
	public void sendFile(String filePath) throws FileNotFoundException
	{	System.out.println("Sending data to client . . .");
		try 
		{	
			buffer=(filePath+"\n").getBytes();
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length,address,port);
			File f=new File(filePath);
			Scanner sc = new Scanner(f);
			String line = new String();
			socket.send(packet); // filename
			while(sc.hasNext())
			{
				line=sc.nextLine(); // read from txt file 
				buffer=(line+"\n").getBytes();
				packet = new DatagramPacket(buffer,buffer.length,address,port);
				//System.out.print(packet.getLength()+" "+new String(buffer, StandardCharsets.UTF_8));
				socket.send(packet);//	send each line to client machine
			}
			buffer=("end\n").getBytes();
			packet = new DatagramPacket(buffer,buffer.length,address,port);
			socket.send(packet);
			
			System.out.println("Data for file "+filePath+" sent");
		} 
		catch (IOException e) {e.printStackTrace();}
	}
	
	public void CloseConnections()
	{
		try {socket.close();} catch (Exception e) {}
	}
	
	public static int getPort()
	{
		return port;
	}

	public static void main(String[] args) throws FileNotFoundException
	{
		if(args.length!=0)
		{
			port=Integer.parseInt(args[0]);
		}
		DatagramSocket socket;
		try 
		{
			socket = new DatagramSocket(1000);
			PictureServer server = new PictureServer(socket);
		 	String s= server.getData();
			String A[]=s.split(" ");
			server.sendFile(A[0]);
			server.sendFile(A[1]);
			System.out.println("\n\nPlayer 2 data\n");
			 s= server.getData();
			 A=s.split(" ");
			server.sendFile(A[0]);
			server.sendFile(A[1]);
			server.CloseConnections();
		}
		catch(Exception e) {System.err.println("\nServer failed\nPlease retry.");}
	}

}

