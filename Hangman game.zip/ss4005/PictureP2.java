/**
 * 
 */
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * @author Sai Tarun Sathyan
 */
public class PictureP2 {
	public static DatagramSocket socket = null;
	public static InetAddress address = null;
	public static DatagramSocket player = null;
	private int port;
	public static byte buffer[]=new byte[1024];
	
	
	public PictureP2(DatagramSocket socket, InetAddress address,int port)
	{
			this.socket=socket;
			this.address=address;
			try 
			{
				player = new DatagramSocket(1112);
			} 
			catch (SocketException e) {e.printStackTrace();}
			//this.port=socket.getPort();
			this.port=port;
	}
	
	/**
	 * Sends a string containing the files needed to be downloaded
	 * @param s
	 */
	public void sendData(String s)
	{
		System.out.println("Sending data to server . . .");
		buffer=s.getBytes();
		DatagramPacket packet=new DatagramPacket(buffer,buffer.length,address,port);
		try
		{
			socket.send(packet);
		}
		catch (IOException e) {e.printStackTrace();}
	}
	
	/**
	 * Used to download the files sent from the server side
	 * @return
	 */
	public String[] downloadFiles()
	{	System.out.println("Waiting for data from server . . .");
		try 
		{	
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
			socket.receive(packet);
			String line = new String(packet.getData(),0,packet.getLength());
			String File1 =("P2_"+line).trim();
			File f1=new File(File1);
			FileWriter fw1 = new FileWriter(f1);
			PrintWriter pw1 = new PrintWriter(fw1);
			
			while(line!=null)//writing into file
			{
				buffer=new byte[1024];
				packet = new DatagramPacket(buffer,buffer.length);
				socket.receive(packet);
				line = new String(packet.getData(),0,packet.getLength());
				if(line.equals("end\n")) {break;}
				pw1.print(line);
				
				//System.out.println(packet.getLength()+" "+line);
			}
			
			DatagramPacket packet2 = new DatagramPacket(buffer,buffer.length);
			socket.receive(packet2);
			String line2 = new String(packet2.getData(),0,packet2.getLength());
			String File2 =("P2_"+line2).trim();
			File f2=new File(File2);
			FileWriter fw2 = new FileWriter(f2);
			PrintWriter pw2 = new PrintWriter(fw2);
			while(line!=null)//writing into file
			{
				buffer=new byte[1024];
				packet2 = new DatagramPacket(buffer,buffer.length);
				socket.receive(packet2);
				line = new String(packet2.getData(),0,packet2.getLength());
				if(line.equals("end\n")) {break;}
				pw2.print(line);
				//System.out.println(packet.getLength()+" "+line);
			}
			
			fw1.close();
			pw1.close();
			fw2.close();
			pw2.close();
			
			String Names[]=new String[2];
			Names[0]=File1;
			Names[1]=File2;
			return Names;
		} 
		catch (IOException e) {e.printStackTrace();}
		return null;
	}
	

		
	/**
	 * Used to get P1's answer
	 * @return
	 */
	public static String getInput()
	{
		System.out.println("************************ Waiting for P1 to enter an input************************\n");
		try 
		{
			buffer=new byte[1024];
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
			player.receive(packet);
			String input = new String(packet.getData(),0,packet.getLength());
			return input;
		} 
		catch (SocketException e1) 
		{e1.printStackTrace();}
		catch (IOException e) {e.printStackTrace();}
		
		return null;
	}
	
	/**
	 * Used to send p2s answer to p1
	 * @param s
	 */
	public static void sendInput(String s)
	{
		DatagramSocket socket;
		try 
		{
			socket = new DatagramSocket();
			buffer=new byte[1024];
			buffer=s.getBytes();
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length,address,1111);
			socket.send(packet);
		} 
		catch (SocketException e1) 
		{e1.printStackTrace();}
		catch (IOException e) {e.printStackTrace();}
		
	}
	
	public void closeConnections() throws IOException
	{
		try
		{socket.close();}catch (Exception e) {}
	}
	

	/**
	 * @param args player names and text file containing the image
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		String name1="Player 1";
		String name2="Player 2";
		String wordfile1="superman";	
		String picfile1="superman.txt";	
		String wordfile2="batman";
		String picfile2="batman.txt";
		String address="127.0.0.1";
		if(args.length!=0)
		{
			//java Picture superman superman.txt batman batman.txt spiegel.cs.rit.edu
			wordfile1=args[0];
			picfile1=args[1];
			wordfile2=args[2];
			picfile2=args[3];	
			address=args[4]; 
		}
		
		
		try {
			int port=PictureServer.getPort();
			DatagramSocket socket = new DatagramSocket();
			InetAddress addr=InetAddress.getLocalHost();
			PictureP2 client = new PictureP2(socket,addr,1000);
			client.sendData(picfile1+" "+picfile2);
			String newNames[]=client.downloadFiles();
			System.out.println();
			picfile1=newNames[0];
			picfile2=newNames[1];
			System.out.println("Download Finished");
			System.out.println("\n\n"+picfile1+" "+picfile2+"\n\n");
			client.closeConnections();
		}
		catch(Exception e)
		{
			System.err.println("Failed to establish connection ");
			System.err.println("Restart ");
		}
		
		
		
		Player1 p1=new Player1(name1,wordfile1,picfile1);
		Player1 p2=new Player1(name2,wordfile2,picfile2);
		PrintPicture1 p=new PrintPicture1();
		Words1 w=new Words1();
		
		Scanner sc=new Scanner(System.in);
		char userInput;
		int turn =1;
		
		//game begins
		
		while(p1.noLettersGuessed<p1.wordToGuess.length && p2.noLettersGuessed<p2.wordToGuess.length)
		{
			if(turn==1)
				{
					char p1Input=getInput().charAt(0);
					System.out.println();
					System.out.print(p1.name+ "("+String.valueOf(p1.playerGuess).trim()+") :-");
					System.out.println(p1Input);
					
					//userInput=sc.next().charAt(0);
					System.out.println(p2.name+ "("+String.valueOf(p2.playerGuess).trim()+") :-");
					
					p1.playerGuess=w.wordCompare(p1.wordToGuess,p1Input,p1.playerGuess);
					//System.out.println("Original String:"+String.valueOf(p1.wordToGuess));
					//System.out.println("Players guess: "+String.valueOf(p1.playerGuess));
					
					
					if(w.letterCompare(p1.wordToGuess,p1Input))
					{
						p1.noLettersGuessed++;
						System.out.println("You guess was correct: "+String.valueOf(p1.playerGuess).trim());
						if(String.valueOf(p1.wordToGuess).equals("superman"))
						{p.supermanPrint(p1.noLettersGuessed,p1.picFile);}
						else
						{p.batmanPrint(p1.noLettersGuessed,p1.picFile);}
						p1.wordToGuess=w.updateOriginalWord(p1.wordToGuess,p1Input);
					}
					else
					{
						turn =2;	
					}
						
					
				}
				
			else
				{
				System.out.println("******************************" +p2.name+"s turn  "
						+ "******************************");
				System.out.println();
				System.out.println(p1.name+ "("+String.valueOf(p1.playerGuess).trim()+") :-");
				System.out.print(p2.name+ "("+String.valueOf(p2.playerGuess).trim()+") :-");
				userInput=sc.next().charAt(0);
				sendInput(String.valueOf(userInput));
				System.out.println();
				p2.playerGuess=w.wordCompare(p2.wordToGuess,userInput,p2.playerGuess);
				//System.out.println("Original String:"+String.valueOf(p2.wordToGuess));
				//System.out.println("Players guess: "+String.valueOf(p2.playerGuess));
				
				
				if(w.letterCompare(p2.wordToGuess,userInput))
				{
					p2.noLettersGuessed++;
					System.out.println("You guess was correct: "+String.valueOf(p2.playerGuess).trim());
					if(String.valueOf(p2.wordToGuess).equals("superman"))
					{p.supermanPrint(p2.noLettersGuessed,p2.picFile);}
					else
					{p.batmanPrint(p2.noLettersGuessed,p2.picFile);}
					p2.wordToGuess=w.updateOriginalWord(p2.wordToGuess,userInput);
				}
				else
				{
					turn =2;	
				}
			
		}
		
		if(p1.noLettersGuessed == p1.wordToGuess.length)
		{
			System.out.println("******************************  "+p1.name+" wins!!!"
					+ "******************************");
		}
		
		if(p2.noLettersGuessed == p2.wordToGuess.length)
		{
			System.out.println("****************************** "+p2.name+" wins!!!  "
					+ "******************************");
		}
		
		
	}
		sc.close();
		
}
	
}


/**
 * this class is used to track the players guess and
 * the word that they need to guess
 *
 */
class Player2{
	String name;
	char playerGuess[]=new char[20];
	int noLettersGuessed=0;
	char wordToGuess[]=new char[20];
	String picFile;
	Player2(String name,String filePath,String picFile) throws IOException
	{	
		this.picFile=picFile;
		
		//File f=new File(filePath);
		//BufferedReader br=new BufferedReader(new FileReader(f));
		//this.wordToGuess=((br.readLine()).toLowerCase()).toCharArray();
		this.wordToGuess=filePath.toLowerCase().toCharArray();
		this.name=name;
		
		int l=this.wordToGuess.length;
		for(int i=0;i<l;i++)
			playerGuess[i]='.';
		//br.close();
	}
}


class Words2{
	/**
	 * This function is used to compare a character given by the user with a 
	 * previously defined word if the user character is found in the pre-existing
	 * array then we update a new string called letters guessed by adding that 
	 * user-input in the letters guessed array(this addition is done in the same
	 * index it was found in the original array)
	 *  
	 * @param 		original 				it's the original array that has the letters we 
	 * 												are looking for
	 * @param			userInput			it's the character given by the user
	 * @param			lettersGuessed	it's an array containing the letters that user has 
	 * 												already guessed(this will be further updated now)
	 * 
	 * @return			lettersGuessed	the update array of letters guessed will be returned 	
	 * 
	 * @exception	IOException		when file does not exist at given path
	 */
	public char[] wordCompare(char[] original,char userInput, char[]  lettersGuessed)
	{
		int length=original.length;
		//System.out.println("Array length :- "+length);
		for(int i=0;i<length;i++)
		{
			if(userInput==original[i])
			{
				lettersGuessed[i]=original[i];
				break;
			}
		}
		return lettersGuessed;
	}

	/**
	 *  This function is used to compare if the user input exists in the original 
	 *  array and if the answer is yes then we return true , this is used in the
	 * 	 if statement to check if each letter guessed by the user is correct or not
	 *  
	 * @param original				it's the original array that has the letters we
	 * 																				 are looking for		
	 * @param userInput			it's the character given by the user
	 * 
	 * @return	 boolean				returns true if user input is identified in
	 * 											 original array else returns false
	 */
	public boolean letterCompare(char[] original,char userInput)
	{	int length=original.length;
		int count=0;
		for(int i=0;i<length;i++)
		{
			if(userInput==original[i])
			{
				count=1;
				break;
			}
			else
				count=0;
			
			
		}
		if(count==1)
			return true;
		else
			return false;
			
	}

	/**
	 *  This function is used to cross-off the correctly guessed letters in the original
	 *  array , this is done so that the user does not get another turn for guessing a 
	 *  previously guessed word
	 *  
	 * @param original			it's the original array that has the letters we
	 * 										are looking for
	 * @param userInput 		it's the character given by the user
	 * 
	 * @return	 original			we return the updated original array
	 */
	public char[] updateOriginalWord(char [] original,char userInput)
	{
		int length=original.length;
		for(int i=0;i<length;i++)
		{
			if(userInput==original[i])
			{
				original[i]="*".charAt(0);
				break;
			}
		}
		return original;
	}

}
class PrintPicture2{
	
	/**
	 * The function numberOfLines is used to return the number of lines within a 
	 * given file this value is stored in variable count . The variable count gets 
	 * incremented as we iterate through each line of the file.
	 * 
	 * @param 	filePath 			is the string value of the file's location 
	 * 
	 * @return 	count				stores the number of lines in the file
	 * 
	 * @throws 	IOException  	when file does not exist at given path
	 * 
	 */
	public int numberOfLines(String filePath) {
		int count=0;
		try {
		      File file = new File(filePath);
		      Scanner sc = new Scanner(file);
		      // count number of lines
		      while(sc.hasNextLine()) {
		        sc.nextLine();
		        count++;
		      }
		      sc.close();
		    } catch (Exception e) {
		      e.getStackTrace();
		    }
		return count;
	}
	
	/**
	 * This function is used to print out part of the the Bat-man image , depending  
	 * on the given parameter
	 *  
	 * @param 		n 		used to identify what fraction of the picture should 
	 * 									be displayed
	 * 
	 * @exception	IOException	when file does not exist at given path
	 */
	public void batmanPrint(int n,String filePath2) {
		if(n>6)
		{
			//System.out.println("Enter a number between 1-6");
		}
		try {
			//Creating file objects
			File f=new File(filePath2);
			FileReader fr= new FileReader(f);
			BufferedReader br= new BufferedReader(fr);
			int noLines=numberOfLines(filePath2);

			char[][] data= new char[noLines][80];

			int i=0;
			int j=0;
			int range=11-n;
			while(i<noLines) 
			{	data[i]=(br.readLine()).toCharArray();
				for(j=0;j<80;j++)
					{
					int x=(int) Math.round(Math.random()*(range));
					//System.out.println(x);
					if(x<n&&n!=0)
					{System.out.print(data[i][j]);}
					else
					{System.out.print(".");}
					
					}
				System.out.println();
				i++;
			}
			System.out.println();
			br.close();
			fr.close();
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This function is used to print out part of the the Super-man image , 
	 *  depending on the given parameter
	 *  
	 * @param 		n 		used to identify what fraction of the picture should 
	 * 								 be displayed
	 * 
	 * @exception	IOException	when file does not exist at given path
	 */
	public void supermanPrint(int n, String filePath1) {
		if(n>8)
		{System.out.println("Enter a number between 1-8");}
		try 
		{
			//Creating file objects
			File f=new File(filePath1);
			FileReader fr= new FileReader(f);
			BufferedReader br= new BufferedReader(fr);
			int noLines=numberOfLines(filePath1);

			char[][] data= new char[80][noLines];

			int i=0;
			int j=0;
			int range=15-n;
			while(i<noLines) 
			{	data[i]=(br.readLine()).toCharArray();
				for(j=0;j<80;j++)
					{
						int x=(int) Math.round(Math.random()*(range));
						if(x<n&&n!=0)
						{System.out.print(data[i][j]);}
						else
						{System.out.print(".");}
					
					}
				System.out.println();
				i++;
			}
				System.out.println();
				br.close();
				fr.close();
		}catch(IOException e) 
			{
				e.printStackTrace();
			}
	}
	
}


